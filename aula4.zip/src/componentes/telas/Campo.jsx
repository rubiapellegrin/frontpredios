function Campo({label,type,classe, id, name,value, onChange}){
    return(
        <div className="form-group">
                <label htmlFor={id} className="form-label">
                    {label}
                </label>
                <input
                    type={type}
                    className={classe}
                    id={id}
                    name={name}
                    value={value}
                    onChange={onChange}
                />
            </div>
    )
};
export default Campo;