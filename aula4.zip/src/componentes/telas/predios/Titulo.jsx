function Titulo({texto}){
    return(
        <h1>{texto}</h1>
    )
};
export default Titulo;