import React from 'react';

const PredioContext = React.createContext();
 
export default PredioContext;