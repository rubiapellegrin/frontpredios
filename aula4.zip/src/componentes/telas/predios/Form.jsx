import { useContext } from 'react'
import Alerta from '../../Alerta';
import Campo from '../Campo';
import Dialogo from './Dialogo';
import PredioContext from './PredioContext';

function Form() {

    const { objeto, handleChange, acaoCadastrar, alerta } = useContext(PredioContext);
    (() => {
        'use strict'

        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        const forms = document.querySelectorAll('.needs-validation')

        // Loop over them and prevent submission
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }

                form.classList.add('was-validated')
            }, false)
        })
    })()

    return (
        <Dialogo acao={acaoCadastrar}>
            <Alerta alerta={alerta} />
            <Campo label="codigo" type="text" classe="form-control" id="txtCodido"
            name="codigo" value={objeto.codigo}
            onChange={handleChange} />

            
            <div className="form-group">
                <label htmlFor="txtNome" className="form-label">
                    Nome
                </label>
                <input
                    type="text"
                    className="form-control"
                    id="txtNome"
                    name="nome"
                    value={objeto.nome}
                    onChange={handleChange}
                    required
                />
                <div className="valid-feedback">
                    OK
                </div>

                <div class="invalid-feedback">
                    Informe o nome
                </div>
            </div>
            <div className="form-group">
                <label htmlFor="txtDescricao" className="form-label">
                    Descrição
                </label>
                <input
                    type="text"
                    className="form-control"
                    id="txtSite"
                    name="descricao"
                    value={objeto.descricao}
                    onChange={handleChange}
                    required
                />
                <div className="valid-feedback">
                    OK
                </div>

                <div class="invalid-feedback">
                    Informe a descricao
                </div>
            </div>
            <div className="form-group">
                <label htmlFor="txtSigla" className="form-label">
                    Sigla
                </label>
                <input
                    type="text"
                    className="form-control"
                    id="txtSigla"
                    maxLength="4"
                    name="sigla"
                    value={objeto.sigla}
                    onChange={handleChange}
                    required
                />
                <div className="valid-feedback">
                    OK
                </div>

                <div class="invalid-feedback">
                    Informe a sigla
                </div>
            </div>
        </Dialogo>



    )
}

export default Form;