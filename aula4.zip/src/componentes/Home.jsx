const Home = () => (
    <div>
        <h1>Salas de Aula - PWA</h1>
    </div>
);
export default Home;